package com.example.androidworkshop;

import android.os.Bundle;
import android.widget.TextView;
import androidx.appcompat.app.AppCompatActivity;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;
import android.widget.EditText;
import android.widget.ImageView;
import com.google.android.material.floatingactionbutton.FloatingActionButton;
import java.util.List;

public class Einkaufsliste extends AppCompatActivity {
    private RecyclerView recyclerView;
    private MyRecyclerViewAdapter adapter;
    private ShoppingList currentList;
    private EditText itemInput;
    private ImageView addItemButton;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_einkaufsliste);

        String listName = getIntent().getStringExtra("list_name");
        currentList = getShoppingListByName(listName);

        if (currentList == null) {
            finish(); // Beendet die Aktivität, wenn die Liste nicht gefunden wird
            return;
        }

        // Setzen des dynamischen Titels
        TextView title = findViewById(R.id.textView2);
        title.setText(currentList.getName());

        recyclerView = findViewById(R.id.recyclerview);
        recyclerView.setLayoutManager(new LinearLayoutManager(this));

        adapter = new MyRecyclerViewAdapter(this, currentList.getItems());
        recyclerView.setAdapter(adapter);

        itemInput = findViewById(R.id.itemInput);
        addItemButton = findViewById(R.id.addItemButton);

        addItemButton.setOnClickListener(v -> {
            String itemName = itemInput.getText().toString();
            if (!itemName.isEmpty()) {
                currentList.addItem(itemName);
                adapter.notifyDataSetChanged();
                itemInput.setText("");
            }
        });

        FloatingActionButton clearButton = findViewById(R.id.clearButton);
        clearButton.setOnClickListener(view -> {
            currentList.clearItems();
            adapter.notifyDataSetChanged();
        });
    }

    private ShoppingList getShoppingListByName(String name) {
        List<ShoppingList> lists = ShoppingListManager.getShoppingLists();
        for (ShoppingList list : lists) {
            if (list.getName().equals(name)) {
                return list;
            }
        }
        return null;
    }
}
