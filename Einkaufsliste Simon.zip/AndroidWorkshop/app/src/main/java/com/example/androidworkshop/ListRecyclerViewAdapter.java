package com.example.androidworkshop;

import android.content.Context;
import android.content.Intent;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ImageView;
import android.widget.TextView;
import android.widget.Toast;
import androidx.recyclerview.widget.RecyclerView;
import java.util.List;

public class ListRecyclerViewAdapter extends RecyclerView.Adapter<ListRecyclerViewAdapter.ViewHolder> {

    private List<ShoppingList> mData;
    private LayoutInflater mInflater;
    private Context context;

    public ListRecyclerViewAdapter(Context context, List<ShoppingList> data) {
        this.mInflater = LayoutInflater.from(context);
        this.mData = data;
        this.context = context;
    }

    @Override
    public ViewHolder onCreateViewHolder(ViewGroup parent, int viewType) {
        View view = mInflater.inflate(R.layout.recyclerview_list_row, parent, false);
        return new ViewHolder(view);
    }

    @Override
    public void onBindViewHolder(ViewHolder holder, int position) {
        ShoppingList list = mData.get(position);
        holder.listNameTextView.setText(list.getName());

        holder.itemView.setOnClickListener(view -> {
            Intent intent = new Intent(view.getContext(), Einkaufsliste.class);
            intent.putExtra("list_name", list.getName());
            context.startActivity(intent);
        });

        holder.deleteListButton.setOnClickListener(v -> {
            ShoppingListManager.removeList(mData.get(position));
            mData.remove(position);
            notifyItemRemoved(position);
            notifyItemRangeChanged(position, mData.size());
            Toast.makeText(context, "Liste gelöscht", Toast.LENGTH_SHORT).show();
        });
    }

    @Override
    public int getItemCount() {
        return mData.size();
    }

    public class ViewHolder extends RecyclerView.ViewHolder {
        TextView listNameTextView;
        ImageView deleteListButton;

        ViewHolder(View itemView) {
            super(itemView);
            listNameTextView = itemView.findViewById(R.id.listNameTextView);
            deleteListButton = itemView.findViewById(R.id.deleteButton);
        }
    }
}
