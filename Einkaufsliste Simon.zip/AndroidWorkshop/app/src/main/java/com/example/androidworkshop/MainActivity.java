package com.example.androidworkshop;

import android.content.Context;
import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.EditText;
import android.widget.ImageView;
import androidx.appcompat.app.AppCompatActivity;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;
import java.util.ArrayList;
import java.util.List;

public class MainActivity extends AppCompatActivity {
    private List<ShoppingList> shoppingLists;
    private ListRecyclerViewAdapter adapter;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        shoppingLists = ShoppingListManager.getShoppingLists();

        RecyclerView recyclerView = findViewById(R.id.listRecyclerView);
        recyclerView.setLayoutManager(new LinearLayoutManager(this));

        adapter = new ListRecyclerViewAdapter(this, shoppingLists);
        recyclerView.setAdapter(adapter);

        EditText listNameInput = findViewById(R.id.listNameInput);
        ImageView addListButton = findViewById(R.id.addListButton);

        addListButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                String listName = listNameInput.getText().toString();
                if (!listName.isEmpty()) {
                    ShoppingList newList = new ShoppingList(listName);
                    ShoppingListManager.addList(newList); // Add the list to the manager
                    adapter.notifyDataSetChanged();
                    listNameInput.setText("");
                }
            }
        });
    }
}
