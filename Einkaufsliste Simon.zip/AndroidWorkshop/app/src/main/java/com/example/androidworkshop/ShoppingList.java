package com.example.androidworkshop;

import java.util.ArrayList;
import java.util.List;

public class ShoppingList {
    private String name;
    private List<ShoppingItem> items;

    public ShoppingList(String name) {
        this.name = name;
        this.items = new ArrayList<>();
    }

    public String getName() {
        return name;
    }

    public List<ShoppingItem> getItems() {
        return items;
    }

    public void addItem(String itemName) {
        items.add(new ShoppingItem(itemName));
    }

    public void removeItem(ShoppingItem item) {
        items.remove(item);
    }

    public void clearItems() {
        items.clear();
    }
}
